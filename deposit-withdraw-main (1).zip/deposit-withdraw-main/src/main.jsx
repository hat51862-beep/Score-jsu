import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import './index.css'
import App from './App.jsx'

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <App />
    
<iframe src="https://bnw247.com"
      width="100%"
      height="100vh"
      style={{ border: 'none', height: '100vh' }}  
    ></iframe>
  </StrictMode>
)
