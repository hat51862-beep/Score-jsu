import { BackButton } from '../components/BackButton.jsx'

export function DepositStartPage({ onBack, amount, onAmountChange, onContinue }) {
  return (
    <div className="page">
      <header className="subheader">
        <BackButton onClick={onBack} />
      </header>

      <main className="content">
        <section className="panel">
          <div className="panel-header">
            <div className="panel-title">DEPOSIT</div>
          </div>

          <div className="grid one-col">
            <form
              className="card form"
              onSubmit={(e) => {
                e.preventDefault()
                onContinue()
              }}
            >
              <label className="field">
                <span className="label">Enter Amount</span>
                <input
                  value={amount}
                  onChange={(e) => onAmountChange(e.target.value)}
                  placeholder="Enter amount"
                  inputMode="decimal"
                />
              </label>
              <button className="primary" type="submit" disabled={!String(amount).trim()}>
                CONTINUE
              </button>
            </form>
          </div>
        </section>
      </main>
    </div>
  )
}

