import { BackButton } from '../components/BackButton.jsx'

export function WithdrawPage({ onBack, form, onFormChange, onSubmitWithdraw }) {
  const bankOk = form.accountName.trim() && form.ifsc.trim()
  const upiOk = form.upiOrPhone.trim()
  const baseOk =
    form.amount.trim() &&
    form.userName.trim() &&
    (form.mode === 'bank' ? bankOk : upiOk)

  return (
    <div className="page">
      <header className="subheader">
        <BackButton onClick={onBack} />
      </header>

      <main className="content">
        <section className="panel">
          <div className="panel-top">
            <div className="method-tabs" role="tablist" aria-label="Withdrawal payout method">
              <div className="method-scroll method-scroll--withdraw">
                <button
                  type="button"
                  role="tab"
                  aria-selected={form.mode === 'bank'}
                  className={form.mode === 'bank' ? 'method method-active' : 'method'}
                  onClick={() => onFormChange({ ...form, mode: 'bank' })}
                >
                  <span className="method-label">BANK{'\n'}ACCOUNT</span>
                </button>
                <span className="withdraw-method-or" aria-hidden="true">
                  OR
                </span>
                <button
                  type="button"
                  role="tab"
                  aria-selected={form.mode === 'upi'}
                  className={form.mode === 'upi' ? 'method method-active' : 'method'}
                  onClick={() => onFormChange({ ...form, mode: 'upi' })}
                >
                  <span className="method-label">UPI /{'\n'}PHONEPE</span>
                </button>
              </div>
            </div>
          </div>

          <div className="panel-header">
            <div className="panel-title">Withdrawal</div>
          </div>

          <div className="grid one-col">
            <form className="card form" onSubmit={onSubmitWithdraw}>
              {form.mode === 'bank' ? (
                <>
                  <label className="field">
                    <span className="label">
                      Account Name <span className="req">*</span>
                    </span>
                    <input
                      value={form.accountName}
                      onChange={(e) => onFormChange({ ...form, accountName: e.target.value })}
                      placeholder="Account holder name"
                      inputMode="text"
                      autoComplete="name"
                    />
                  </label>
                  <label className="field">
                    <span className="label">
                      IFSC Code <span className="req">*</span>
                    </span>
                    <input
                      value={form.ifsc}
                      onChange={(e) => onFormChange({ ...form, ifsc: e.target.value.toUpperCase() })}
                      placeholder="e.g. ABCD0123456"
                      autoComplete="off"
                    />
                  </label>
                </>
              ) : (
                <label className="field">
                  <span className="label">
                    UPI / PhonePe No. <span className="req">*</span>
                  </span>
                  <input
                    value={form.upiOrPhone}
                    onChange={(e) => onFormChange({ ...form, upiOrPhone: e.target.value })}
                    placeholder="UPI ID or PhonePe number"
                    inputMode="text"
                    autoComplete="off"
                  />
                </label>
              )}

              <label className="field">
                <span className="label">
                  Amount <span className="req">*</span>
                </span>
                <input
                  value={form.amount}
                  type='number'
                  onChange={(e) => onFormChange({ ...form, amount: e.target.value })}
                  placeholder="Enter amount"
                  inputMode="decimal"
                />
              </label>

              <label className="field">
                <span className="label">
                  UserName <span className="req">*</span>
                </span>
                <input
                  value={form.userName}
                  onChange={(e) => onFormChange({ ...form, userName: e.target.value })}
                  placeholder="Enter user name"
                  inputMode="text"
                />
              </label>

              <button className="primary" type="submit" disabled={!baseOk}>
                SUBMIT
              </button>
            </form>
          </div>
        </section>
      </main>
    </div>
  )
}
