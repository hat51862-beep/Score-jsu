import { BackButton } from '../components/BackButton.jsx'
import { CopyIconButton } from '../components/CopyIconButton.jsx'
import { DepositMethodTabs } from '../components/DepositMethodTabs.jsx'

function CopyableValue({ children, copyValue, copyLabel }) {
  return (
    <div className="v v-with-copy">
      <span className="v-text">{children}</span>
      <CopyIconButton value={copyValue} label={copyLabel} />
    </div>
  )
}

export function DepositPage({
  onBack,
  method,
  onMethodChange,
  form,
  onFormChange,
  onSubmit,
  onWhatsAppShare,
}) {
  return (
    <div className="page">
      <header className="subheader">
        <BackButton onClick={onBack} />
      </header>

      <main className="content">
        <div className="panel">
          <div className="panel-top">
            <DepositMethodTabs value={method} onChange={onMethodChange} onWhatsAppShare={onWhatsAppShare} />
          </div>

          <div className="panel-header">
            <div className="panel-title">BANK ACCOUNT</div>
          </div>

          <div className="grid">
            <aside className="card">
              <div className="kv">
                <div className="k">Bank Name</div>
                <CopyableValue copyValue="Fino bank" copyLabel="bank name">
                  Fino bank
                </CopyableValue>
              </div>
              <div className="kv">
                <div className="k">A/C No</div>
                <CopyableValue copyValue="20414166840" copyLabel="account number">
                  20414166840
                </CopyableValue>
              </div>
              <div className="kv">
                <div className="k">IFSC Code</div>
                <CopyableValue copyValue="FINO0001561" copyLabel="IFSC code">
                  FINO0001561
                </CopyableValue>
              </div>
              <div className="kv">
                <div className="k">Account Name</div>
                <CopyableValue copyValue="RITESH" copyLabel="account name">
                  RITESH
                </CopyableValue>
              </div>
             
              {/* <div className="kv">
                <div className="k">Min Amount</div>
                <div className="v">300</div>
              </div>
              <div className="kv">
                <div className="k">Max Amount</div>
                <div className="v">100000</div>
              </div> */}
            </aside>

            <form className="card form" onSubmit={onSubmit}>
              <label className="field">
                <span className="label">
                  Unique Transaction Reference <span className="req">*</span>
                </span>
                <input
                  value={form.utr}
                  onChange={(e) => onFormChange({ ...form, utr: e.target.value })}
                  placeholder="6 to 12 Digit UTR Number"
                  inputMode="numeric"
                />
                {!form.utr.trim() ? <span className="hint error">Please enter your UTR ID</span> : null}
              </label>

              <label className="field">
                <span className="label">
                  Amount <span className="req">*</span>
                </span>
                <input
                  value={form.amount}
                  type='number'
                  onChange={(e) => onFormChange({ ...form, amount: e.target.value })}
                  placeholder="1000"
                  inputMode="decimal"
                />
              </label>
              <label className="field">
                <span className="label">
                  UserName <span className="req">*</span>
                </span>
                <input
                  value={form.userName}
                  onChange={(e) => onFormChange({ ...form, userName: e.target.value })}
                  placeholder="Enter User Name"
                  inputMode="text"
                />
              </label>

              <label className="checkbox">
                <input
                  type="checkbox"
                  checked={form.agreed}
                  onChange={(e) => onFormChange({ ...form, agreed: e.target.checked })}
                />
                <span>I have read and agree with the terms of payment and withdrawal policy.</span>
              </label>
              {!form.agreed ? <div className="hint error">Please check terms and condition</div> : null}

              <button
                className="primary"
                type="submit"
                disabled={!form.agreed || !form.utr.trim() || !form.userName}
              >
                SUBMIT
              </button>
            </form>
          </div>
        </div>
      </main>
    </div>
  )
}

