import { useState } from 'react'
import './App.css'
import { HeaderBar } from './components/HeaderBar.jsx'
import { DepositPage } from './pages/DepositPage.jsx'
import { WithdrawPage } from './pages/WithdrawPage.jsx'
import { DepositStartPage } from './pages/DepositStartPage.jsx'

function App() {
  const [route, setRoute] = useState('home') // home | depositStart | deposit | withdraw
  const [depositMethod, setDepositMethod] = useState('account')
  const [depositStartAmount, setDepositStartAmount] = useState('')

  /** Full international number for wa.me (India +91 8962063615) */
  const whatsAppE164 = '918962063615'

  function openWhatsAppChatOnly() {
    const url = `https://wa.me/${whatsAppE164}`
    globalThis.open?.(url, '_blank', 'noopener,noreferrer')
  }

  function depositMethodLabel(id) {
    if (id === 'whatsapp') return 'WhatsApp Deposit'
    if (id === 'gpay') return 'Google Pay'
    return 'Bank Account'
  }

  function openWhatsAppWithDepositRequest() {
    const text = [
      'Deposit Request',
      `Method: ${depositMethodLabel(depositMethod)}`,
      `Amount: ${depositForm.amount || ''}`,
      `UTR: ${depositForm.utr || ''}`,
      `UserName: ${depositForm.userName || ''}`,
      `Agreed: ${depositForm.agreed ? 'Yes' : 'No'}`,
    ].join('\n')
    const url = `https://wa.me/${whatsAppE164}?text=${encodeURIComponent(text)}`
    globalThis.open?.(url, '_blank', 'noopener,noreferrer')
  }

  const [depositForm, setDepositForm] = useState({
    utr: '',
    amount: '1000',
    userName: '',
    agreed: false,
  })

  const [withdrawForm, setWithdrawForm] = useState({
    mode: 'bank',
    accountName: '',
    ifsc: '',
    upiOrPhone: '',
    amount: '',
    userName: '',
  })

  function openWhatsAppWithWithdrawRequest() {
    const lines = [
      'Withdrawal Request',
      `Method: ${withdrawForm.mode === 'bank' ? 'Bank Account' : 'UPI / PhonePe'}`,
      `Amount: ${withdrawForm.amount || ''}`,
      `UserName: ${withdrawForm.userName || ''}`,
    ]
    if (withdrawForm.mode === 'bank') {
      lines.push(`Account Name: ${withdrawForm.accountName || ''}`)
      lines.push(`IFSC: ${withdrawForm.ifsc || ''}`)
    } else {
      lines.push(`UPI/PhonePe: ${withdrawForm.upiOrPhone || ''}`)
    }
    const text = lines.join('\n')
    const url = `https://wa.me/${whatsAppE164}?text=${encodeURIComponent(text)}`
    globalThis.open?.(url, '_blank', 'noopener,noreferrer')
  }

  function openDeposit() {
    setRoute('depositStart')
  }

  function openWithdraw() {
    setRoute('withdraw')
  }

  function goHome() {
    setRoute('home')
  }

  function onSubmitDeposit(e) {
    e.preventDefault()
    openWhatsAppWithDepositRequest()
  }

  function onSubmitWithdraw(e) {
    e.preventDefault()
    openWhatsAppWithWithdrawRequest()
  }

  return (
    <>
      <HeaderBar onDeposit={openDeposit} onWithdraw={openWithdraw} />
      {route === 'home' ? <div className="home-spacers" /> : null}

      {route === 'depositStart' ? (
        <DepositStartPage
          onBack={goHome}
          amount={depositStartAmount}
          onAmountChange={setDepositStartAmount}
          onContinue={() => {
            setDepositForm((p) => ({ ...p, amount: String(depositStartAmount || '').trim() }))
            setRoute('deposit')
          }}
        />
      ) : null}

      {route === 'deposit' ? (
        <DepositPage
          onBack={goHome}
          method={depositMethod}
          onMethodChange={setDepositMethod}
          form={depositForm}
          onFormChange={setDepositForm}
          onSubmit={onSubmitDeposit}
          onWhatsAppShare={openWhatsAppChatOnly}
        />
      ) : null}

      {route === 'withdraw' ? (
        <WithdrawPage
          onBack={goHome}
          form={withdrawForm}
          onFormChange={setWithdrawForm}
          onSubmitWithdraw={onSubmitWithdraw}
        />
      ) : null}
    </>
  )
}

export default App
