function WhatsAppIcon() {
  return (
    <img
      src="https://a2t.land/images/icon/whatsapp.png"
      alt="WhatsApp"
      width="34"
      height="34"
      style={{ display: 'block' }}
    />
  )
}

function BankIcon({ color = '#b31515' }) {
  return (
    <svg width="34" height="34" viewBox="0 0 24 24" aria-hidden="true">
      <path
        fill={color}
        d="M12 2 2 7v2h20V7L12 2Zm-7 9v8h2v-8H5Zm4 0v8h2v-8H9Zm4 0v8h2v-8h-2Zm4 0v8h2v-8h-2ZM3 21h18v-2H3v2Z"
      />
    </svg>
  )
}

function GPayIcon() {
  return (
    <svg width="34" height="34" viewBox="0 0 64 64" aria-hidden="true">
      <path fill="#1a73e8" d="M26.2 33.3c0-7.3 5.2-13.1 12.8-13.1 4.1 0 6.7 1.6 8.7 3.5l-3 3c-1.2-1.1-2.9-2.2-5.7-2.2-4.7 0-8.2 3.8-8.2 8.8s3.5 8.8 8.2 8.8c3 0 4.8-1.2 5.9-2.2 1-1 1.7-2.4 1.9-4.3h-7.8v-4.2h11.9c.1.6.2 1.4.2 2.4 0 2.9-.8 6.5-3.3 9-2.4 2.5-5.5 3.8-9 3.8-7.6 0-12.6-5.9-12.6-13.2Z" />
      <path fill="#34a853" d="M58.1 31.2v-3.1h-3v3.1h-3v3h3v3.1h3v-3.1h3v-3h-3Z" />
      <path fill="#5f6368" d="M18.3 45.8V18.7h4.6v27.1h-4.6Z" />
      <path fill="#5f6368" d="M6.8 45.8V18.7h10.9c5.2 0 8.4 3.4 8.4 7.9 0 4.6-3.2 7.9-8.4 7.9H11.4v11.3H6.8Zm4.6-15.5h6.1c2.7 0 4.2-1.6 4.2-3.7 0-2.1-1.5-3.7-4.2-3.7h-6.1v7.4Z" />
    </svg>
  )
}

const METHODS = [
  { id: 'whatsapp', label: 'WHATSAPP\nDEPOSIT', icon: 'whatsapp' },
  { id: 'account', label: 'ACCOUNT', icon: 'bank-red' },
  { id: 'gpay', label: 'GPAY', icon: 'gpay' },
]

function MethodIcon({ type }) {
  if (type === 'whatsapp') return <WhatsAppIcon />
  if (type === 'gpay') return <GPayIcon />
  if (type === 'bank-red') return <BankIcon color="#b31515" />
  return <BankIcon color="#1d4ed8" />
}

export function DepositMethodTabs({ value, onChange, onWhatsAppShare }) {
  return (
    <div className="method-tabs" role="tablist" aria-label="Deposit methods">
      <div className="method-scroll">
        {METHODS.map((m) => (
          <button
            key={m.id}
            type="button"
            role="tab"
            aria-selected={value === m.id}
            className={value === m.id ? 'method method-active' : 'method'}
            onClick={() => {
              onChange(m.id)
              if (m.id === 'whatsapp') onWhatsAppShare?.()
            }}
          >
            <span className="method-icon">
              <MethodIcon type={m.icon} />
            </span>
            <span className="method-label">{m.label}</span>
          </button>
        ))}
      </div>
    </div>
  )
}

