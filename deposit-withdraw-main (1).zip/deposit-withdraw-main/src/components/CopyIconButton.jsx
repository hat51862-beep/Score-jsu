import { useCallback, useRef, useState } from 'react'

export function CopyIconButton({ value, label }) {
  const [copied, setCopied] = useState(false)
  const resetTimerRef = useRef(0)

  const copy = useCallback(async () => {
    const text = String(value ?? '').trim()
    if (!text) return

    try {
      await navigator.clipboard.writeText(text)
    } catch {
      try {
        const ta = document.createElement('textarea')
        ta.value = text
        ta.setAttribute('readonly', '')
        ta.style.position = 'fixed'
        ta.style.left = '-9999px'
        document.body.appendChild(ta)
        ta.select()
        document.execCommand('copy')
        document.body.removeChild(ta)
      } catch {
        return
      }
    }

    clearTimeout(resetTimerRef.current)
    setCopied(true)
    resetTimerRef.current = window.setTimeout(() => setCopied(false), 2000)
  }, [value])

  const tip = copied ? 'Copied' : 'Copy'

  return (
    <span className="copy-control">
      <button
        type="button"
        className={`copy-icon-btn${copied ? ' copy-icon-btn--show-tip' : ''}`}
        aria-label={copied ? `${label} copied` : `Copy ${label}`}
        onClick={copy}
      >
        <svg
          className="copy-icon-btn__svg"
          width="16"
          height="16"
          viewBox="0 0 24 24"
          aria-hidden="true"
        >
          <path
            fill="currentColor"
            d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 18H8V7h11v16z"
          />
        </svg>
        <span className="copy-icon-btn__tip" role="tooltip">
          {tip}
        </span>
      </button>
    </span>
  )
}
