export function BackButton({ onClick }) {
  return (
    <button type="button" className="back-btn" onClick={onClick}>
      ← BACK
    </button>
  )
}

