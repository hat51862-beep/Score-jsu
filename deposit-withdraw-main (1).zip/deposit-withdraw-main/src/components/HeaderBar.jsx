export function HeaderBar({ onDeposit, onWithdraw }) {
  return (
    <header className="headerbar">
      <div className="headerbar-inner">
        <button type="button" className="action action-deposit" onClick={onDeposit}>
          DEPOSIT
        </button>
        <button type="button" className="action action-withdraw" onClick={onWithdraw}>
          WITHDRAW
        </button>
      </div>
    </header>
  )
}

